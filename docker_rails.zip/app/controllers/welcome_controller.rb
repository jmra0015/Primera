
class WelcomeController < ActionController::Base

    def index 
        
    end
end
