class ApplicationController < ActionController::Base

    def application 
        
    end
end
