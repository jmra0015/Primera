# README
1-Autores:  Pepe y Juan Manuel Rey Alvarez

2-Detalles de la pila:  En esta primera versión se usa Ruby on Rails y Sqlite3

3-Ejemplos:  En las próximas versiones se actualizará este punto a medida que se incorporen

4-Pasos para lanzar el contenedor:

- En la carpeta donde se pongan todos los archivos se usa para desplegar la aplicación:
 docker-compose up

- Puede ser necesario si realizas algún cambio en los archivo Gemfile o de Docker hacerlo de la siguiente forma:
 docker-compose build
 docker-compose up 